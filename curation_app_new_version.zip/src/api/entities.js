import { base44 } from './base44Client';


export const UserSignal = base44.entities.UserSignal;

export const Opportunity = base44.entities.Opportunity;



// auth sdk:
export const User = base44.auth;